from os import system
from art import logo
#HINT: You can call clear() to clear the output in the console.
bidders = {}

def add_bid(bid_name,bid_amount):
  bidders[name] = bid

print(logo)
print("Welcome to the secret auction program.")

bidding = True
while bidding is True:
  name = input("What is your name?: ")
  bid = int(input("What's your bid?: $"))
  others = input("Are there any other bidders? Type 'yes' or 'no'. ")
  add_bid(bid_name = name,bid_amount = bid)
  system('clear')
  if others == "no":
    bidding = False
for highest_bidders in bidders:
  highest_bid = 0
  bidd = bidders[highest_bidders]
  if bidd > highest_bid:
    highest_bid = bidd
    highest_bidder = highest_bidders
print(f"The winner is {highest_bidder} with a bid of ${highest_bid}.")