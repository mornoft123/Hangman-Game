#Calculator
from os import system
from art import logo


#Add
def add(n1, n2):
  return n1 + n2

#Subtract
def sub(n1, n2):
  return n1 - n2

#Multiply
def mul(n1, n2):
  return n1 * n2

#Divide
def div(n1, n2):
  if n2 == 0:
    return "Cannot divide a number by 0"
  return n1 / n2
operations = {
            "+":add,
            "-":sub,
            "/":div,
            "*":mul,
}
def calculator():
  system('clear')
  print(logo)
  n1 = float(input("What's the first number?: "))

  new_calculation = True
  
  while new_calculation:
    for operator in operations:
      print(operator)
    operator_sym = input("Pick an operation: ")
    n2 = float(input("Pick another number: "))
    ans = operations[operator_sym](n1, n2)
    print(f"{n1} {operator_sym} {n2} = {ans}")
    if input(f"Would you like to make another calculation with {ans}? 'y' or 'n' ").lower() == 'n':
      new_calculation = False
      calculator()
    else:
      n1 = ans
      system('clear')
      print(logo)
    
    
calculator()

  
  
  
  
  
  