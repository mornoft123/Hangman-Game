import hangman_words
import random
import hangman_art
import os

print(hangman_art.logo)
lives = 6
#chosen_word = word_list[random.randint(0,2)]
chosen_word = random.choice(hangman_words.word_list)  #Word Chosen
usedletter_bank = []
blank_wordlist = []
#20-25:Blank Word Shown
for underscore in range(0, len(chosen_word)):
    blank_wordlist += "_"
print(f"{' '.join(blank_wordlist)}")
print(hangman_art.stages[lives])
#28- :Asking user and checking guess
#while not blank_word == chosen_word:
end_of_game = False
while not end_of_game:
    guess = input("Guess a letter:").lower()
    if guess not in usedletter_bank:
      usedletter_bank.append(guess)
  
    os.system('clear')
  
    if guess not in chosen_word:
        lives -= 1

        print(f"Oops, Looks like {guess}, isn't there.")
    if guess in chosen_word:
        if guess in blank_wordlist:
            print(f"You already used the letter {guess}, see?")
        else:
            print(f"Yes!, {guess} is correct!")
    for position in range(len(chosen_word)):
        guess_check = chosen_word[position]
        if guess_check == guess:
            blank_wordlist[position] = guess_check
    print(f"{' '.join(blank_wordlist)}")
    print(hangman_art.stages[lives])
    print(usedletter_bank)
    #Line 41: Exits While Loop
    if "_" not in blank_wordlist:
        end_of_game = True
        print("You Win!")
    if lives == 0:
        end_of_game = True
        print("You Lose!")
        print(f"The word was {chosen_word}.")
