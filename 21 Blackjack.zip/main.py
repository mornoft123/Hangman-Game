from art import logo
from random import randint
from os import system
import time
############### Blackjack Project #####################

#Difficulty Normal 😎: Use all Hints below to complete the project.
#Difficulty Hard 🤔: Use only Hints 1, 2, 3 to complete the project.
#Difficulty Extra Hard 😭: Only use Hints 1 & 2 to complete the project.
#Difficulty Expert 🤯: Only use Hint 1 to complete the project.

############### Our Blackjack House Rules #####################

## The deck is unlimited in size. 
## There are no jokers. 
## The Jack/Queen/King all count as 10.
## The the Ace can count as 11 or 1.
## Use the following list as the deck of cards:
## cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
## The cards in the list have equal probability of being drawn.
## Cards are not removed from the deck as they are drawn.
## The computer is the dealer.
def blackjack_game():
  def blackjack_res():
    system('clear')
    print(logo)
    print("Welcome to blackjack!")
    print(f"Your hand: {player}, Current score: {p1_score}")
    print(f"Dealer's hand: {dealer}")
  
    
  def draw_card():
    for i in range(2):
      player.append(cards[randint(0,12)])
    for i in range(1):
      dealer.append(cards[randint(0,12)])
  
  def hit():
    if player_turn == True:
      player.append(cards[randint(0,12)])
    if dealer_turn == True:
      dealer.append(cards[randint(0,12)])
  
  
  def player_score():
    score = 0
    for i in player:
      score += i
    return score
  
  def dealer_score():
    score = 0
    for i in dealer:
      score += i
    return score
  
  cards = [11,2,3,4,5,6,7,8,9,10,10,10,10]
  blackjack_ = True
  player_turn = True
  while blackjack_:
    dealer = []
    player = []
    draw_card()
    dealer_turn = False
    while player_turn:
      print(logo)
      print("Welcome to blackjack!")
      p1_score = player_score()
      d1_score = dealer_score()
      print(f"Your hand: {player}, Current score: {p1_score}")
      print(f"Dealer's hand: {dealer}")
      hit_ = True
      if p1_score == 21:
        blackjack_res()
        print("Blackjack! You Win!")
        hit_ = False
        player_turn = False
      while hit_:
        blackjack_res()
        p1_hit = input("Hit or Stand? ").lower()
        time.sleep(3)
        if p1_hit == 'hit':
          hit()
          p1_score = player_score()
          if p1_score == 21:
            hit_ = False
          if p1_score > 21:
            hit_ = False
        else:
          hit_ = False
      player_turn = False  
    dealer_turn = True
    if p1_score == 21:
      blackjack_res()
      print("Blackjack! You Win!")
      dealer_turn = False
    if p1_score > 21:
      blackjack_res()
      print("Bust!, You Lose!")
      dealer_turn = False
    while dealer_turn:
      blackjack_res()
      print("Dealer's turn")
      dealer_hit = True
      if p1_score == 21:
        blackjack_res()
        print("Blackjack! You Win!")
        dealer_hit = False
        player_turn = False
      while dealer_hit:
        blackjack_res()
        hit()
        time.sleep(3)
        d1_score = dealer_score()
        if d1_score == 21:
          blackjack_res()
          print(f"Dealer's score: {d1_score}")
          print("Blackjack! Dealer Wins!")
          dealer_hit = False
        elif d1_score > 21:
          blackjack_res()
          print(f"Dealer's score: {d1_score}")
          print("Dealer bust! You win!")
          dealer_hit = False
        elif d1_score >= 17:
          blackjack_res()
          dealer_hit = False
      dealer_turn = False
    if d1_score < 21 and d1_score > p1_score:
      blackjack_res()
      print(f"Dealer wins with: {d1_score}!")
    elif p1_score < 21 and p1_score > d1_score:
      blackjack_res()
      print(f"Dealer's score: {d1_score}")
      print("You win!")
    elif p1_score == d1_score:
      blackjack_res()
      print(f"Dealer's score: {d1_score}")
      print("Draw!")
    blackjack_ = False 
blackjack_game()
play_again = input("Would you like to play again? 'y' or 'n'\n").lower()
if play_again == 'y':
  blackjack_game()
  
    
  

  












